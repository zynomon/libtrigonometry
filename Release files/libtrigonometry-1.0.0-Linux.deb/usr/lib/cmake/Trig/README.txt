to include this library as a header you
must add 
" find_packages(Trig) " in your cmake file of the root
link it with your project using  " Trig::<what-you-want-to-include> " 

or simply 
                           " Trig::crash "

if you have any questions then come up in github.com/zynomon/libtrigonometry